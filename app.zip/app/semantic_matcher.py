import os
import json
import numpy as np
from typing import List, Tuple, Dict, Any

from app.config import (
    SBERT_MODEL_PATH,
    EMBEDDING_BATCH_SIZE,
    MIN_SIMILARITY_SCORE,
    TOP_K_SECTIONS,
)
from src.embedding_model import TransformerEmbedder
from sklearn.metrics.pairwise import cosine_similarity
from sentence_transformers import util  # Needed for cos_sim


def load_synonyms(file_path="assets/synonyms_lexicon.json") -> dict:
    if not os.path.exists(file_path):
        return {}
    with open(file_path, "r", encoding="utf-8") as f:
        return json.load(f)


class SemanticMatcher:
    def __init__(self):
        self.embedder = TransformerEmbedder(SBERT_MODEL_PATH)
        self.synonyms = load_synonyms()

    def expand_with_synonyms(self, text: str) -> str:
        words = text.split()
        expanded = []
        for word in words:
            expanded.append(word)
            if word in self.synonyms:
                expanded.extend(self.synonyms[word])
        return " ".join(expanded)

    def compute_similarity(
        self, intent_vec: np.ndarray, block_vecs: np.ndarray
    ) -> List[float]:
        sim_scores = cosine_similarity([intent_vec], block_vecs)[0]
        return sim_scores.tolist()

    def rank_blocks(
        self,
        persona_task: str,
        section_blocks: List[Dict[str, Any]]
    ) -> List[Dict[str, Any]]:
        """
        Ranks text blocks by semantic relevance to the persona task.
        """
        # Extract text from blocks, ensure valid input
        all_texts = [block.get("raw", "") for block in section_blocks if isinstance(block, dict)]

        # Filter out invalid entries
        all_texts = [text for text in all_texts if isinstance(text, str) and text.strip()]

        if not all_texts:
            print("[⚠️] No valid text blocks found for semantic ranking.")
            return []

        try:
            # Embed blocks and task
            embeddings = self.embedder.encode(all_texts, batch_size=EMBEDDING_BATCH_SIZE)
            task_embedding = self.embedder.encode([persona_task])[0]
        except Exception as e:
            print(f"[❌] Embedding failed: {e}")
            return []

        # Cosine similarity
        scores = util.cos_sim(task_embedding, embeddings)[0].cpu().tolist()

        # Assign scores to corresponding blocks
        for i, score in enumerate(scores):
            section_blocks[i]["score"] = score

        # Sort by score and return top-K
        section_blocks = sorted(section_blocks[:len(scores)], key=lambda x: x["score"], reverse=True)
        return section_blocks[:TOP_K_SECTIONS]
