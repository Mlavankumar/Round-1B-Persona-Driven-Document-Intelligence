# app/language_utils.py

import fasttext
from app.config import FASTTEXT_LANG_MODEL_PATH, LANG_DETECTION_THRESHOLD

# Load FastText model once
lang_model = fasttext.load_model(FASTTEXT_LANG_MODEL_PATH)


def detect_language_fasttext(text: str) -> str:
    """
    Detects the language of the input text using FastText.

    Args:
        text (str): Input string.

    Returns:
        str: ISO 639-1 language code (e.g., 'en', 'hi', 'ta'), or 'unknown'
    """
    if not text.strip():
        return "unknown"

    text = text.replace("\n", " ")
    prediction = lang_model.predict(text, k=1)

    label, confidence = prediction[0][0], prediction[1][0]
    lang_code = label.replace("__label__", "")

    if confidence >= LANG_DETECTION_THRESHOLD:
        return lang_code
    return "unknown"


def is_supported_language(lang_code: str, supported_languages: list) -> bool:
    """
    Checks if a detected language code is in the list of supported languages.

    Args:
        lang_code (str): Language code from FastText.
        supported_languages (list): List of ISO codes (e.g., ['en', 'hi', 'ta']).

    Returns:
        bool: True if supported, else False.
    """
    return lang_code in supported_languages


# Optional: placeholder for future multilingual translation using MarianMT
def translate_to_english(text: str, source_lang: str) -> str:
    """
    Translate text to English if needed. (Not implemented yet.)

    Args:
        text (str): Original text
        source_lang (str): Source language code

    Returns:
        str: Translated English text (or original if no translation performed)
    """
    # You can implement this using HuggingFace's MarianMT if needed
    return text  # Stub: no translation performed
