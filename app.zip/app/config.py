# app/config.py

import os

# ------------------- Paths -------------------

# Path to quantized multilingual SBERT ONNX model
SBERT_MODEL_PATH = os.path.join("models", "sbert.onnx")

# Path to FastText language detection model
FASTTEXT_LANG_MODEL_PATH = os.path.join("models", "lid.176.bin")

# Optional: Path to entailment model (quantized NLI)
ENTAILMENT_MODEL_PATH = os.path.join("models", "entailment.onnx")  # Optional

# Supported OCR languages (Tesseract)
OCR_LANGUAGES = ["eng", "hin", "tam", "tel", "kan", "ben", "guj"]  # Add as needed

# ------------------- Heuristics -------------------

# Sections to exclude as noise
NOISE_SECTION_KEYWORDS = [
    "table of contents", "index", "references", "bibliography",
    "appendix", "glossary", "acknowledgements", "copyright", "disclaimer"
]

# Minimum number of characters for a page to be considered "content"
MIN_PAGE_TEXT_LENGTH = 200

# ------------------- Embedding & Search -------------------

# SBERT embedding dimensions (pre-PCA)
EMBEDDING_DIM = 768

# Dimensionality after PCA (if used)
REDUCED_DIM = 256

# Batch size for embedding text blocks
EMBEDDING_BATCH_SIZE = 32

# Number of top sections to rank initially
TOP_K_SECTIONS = 20

# ------------------- Clustering -------------------

# MiniBatchKMeans settings
N_CLUSTERS = 3
MAX_SNIPPETS_PER_SECTION = 3
MIN_SNIPPET_WORDS = 20

# ------------------- Thresholds -------------------

# Cosine similarity threshold for relevance
MIN_SIMILARITY_SCORE = 0.60

# Confidence threshold for snippet entailment (if NLI used)
ENTAILMENT_CONFIDENCE_THRESHOLD = 0.80

# Enable entailment model (True to use, False to skip)
ENABLE_ENTAILMENT = True

# Enable zero-shot classifier (True to use, False to skip)
ENABLE_ZERO_SHOT_CLASSIFIER = True

# Threshold score for entailment filtering
MIN_ENTAILMENT_SCORE = 0.80  # You can align this with ENTAILMENT_CONFIDENCE_THRESHOLD

# Threshold score for zero-shot classification filtering
MIN_CLASSIFIER_SCORE = 0.60

# ------------------- Misc -------------------

# OCR DPI threshold (if image is too small, upscale before OCR)
OCR_MIN_DPI = 150

# Language detection confidence threshold (FastText)
LANG_DETECTION_THRESHOLD = 0.70

# Smart truncation max length
MAX_BLOCK_WORDS = 150

# Timestamp format
TIMESTAMP_FORMAT = "%Y-%m-%dT%H:%M:%S"

# Random seed for reproducibility
RANDOM_SEED = 42
