# app/__init__.py

"""
Persona-Driven Document Intelligence System - Core Package

This package includes modules for:
- PDF parsing and OCR fallback
- Multilingual support and language detection
- Persona and job-to-be-done intent encoding
- Section extraction and document graph construction
- Relevance scoring and semantic matching
- Sub-section refinement and JSON generation
"""

__version__ = "1.0.0"
__author__ = "Team PersonaAI"

from . import (
    pdf_parser,
    language_utils,
    intent_encoder,
    section_extractor,
    noise_filter,
    semantic_matcher,
    snippet_refiner,
    output_generator,
)
