# app/zeroshot_classifier.py

import onnxruntime as ort
import numpy as np
from typing import List
from tokenizer.tokenizer_utils import ONNXTokenizer
from app.config import ENTAILMENT_MODEL_PATH, MIN_CLASSIFIER_SCORE


class ZeroShotClassifier:
    def __init__(self):
        self.tokenizer = ONNXTokenizer()
        self.session = ort.InferenceSession(ENTAILMENT_MODEL_PATH)

    def classify(self, text: str, hypothesis: str) -> float:
        inputs = self.tokenizer.encode(text, hypothesis)
        ort_inputs = {k: np.array([v]) for k, v in inputs.items()}

        outputs = self.session.run(None, ort_inputs)[0]
        logits = outputs[0]
        score = float(logits[2])  # "entailment" score
        return score
