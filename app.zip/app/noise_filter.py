import re
import os
from typing import List, Dict


class NoiseFilter:
    def __init__(self, stopwords_path="assets/stopwords.txt"):
        self.min_sentence_length = 20
        self.max_sentence_length = 500

        # Load stopwords from file
        self.stopwords = self.load_stopwords(stopwords_path)

        # Patterns to filter out common noisy lines
        self.noise_patterns = [
            r"^page\s*\d+",                     # Page numbers
            r"^\d{1,2}/\d{1,2}/\d{2,4}$",        # Dates
            r"^table of contents$",              # Table of contents
            r"^figure\s*\d+",                    # Figure labels
            r"^\s*$",                            # Empty lines
            r"^copyright.*",                     # Copyright footer
            r"^www\.",                           # URLs
            r"^appendix\s*[a-zA-Z]*",            # Appendix labels
            r"^\d+\s*$",                         # Single digit or numbered lines
        ]
        self.noise_regex = re.compile("|".join(self.noise_patterns), re.IGNORECASE)

    def load_stopwords(self, file_path: str) -> set:
        """Load stopwords from a file."""
        if not os.path.exists(file_path):
            print(f"[Warning] Stopwords file not found: {file_path}")
            return set()

        with open(file_path, "r", encoding="utf-8") as f:
            return set(line.strip().lower() for line in f if line.strip())

    def is_noisy(self, block: Dict) -> bool:
        """
        Determine if a block is considered noise.
        Assumes each block is a dictionary containing a 'raw' text field.
        """
        text = block.get("raw", "")
        if not isinstance(text, str):
            return True

        text = text.strip()

        if not text:
            return True
        if self.noise_regex.match(text):
            return True
        if len(text) < self.min_sentence_length or len(text) > self.max_sentence_length:
            return True
        if text.lower() in self.stopwords:
            return True
        return False

    def clean_blocks(self, blocks: List[Dict]) -> List[Dict]:
        """
        Removes noisy blocks from extracted sections.

        Args:
            blocks (List[Dict]): List of section blocks (each block is a dict with 'raw' key)

        Returns:
            List[Dict]: Cleaned list of section blocks
        """
        return [block for block in blocks if not self.is_noisy(block)]
