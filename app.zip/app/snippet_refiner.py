from typing import List, Dict, Tuple
from app.zeroshot_classifier import ZeroShotClassifier
from app.entailment_checker import EntailmentChecker
from app.config import (
    ENABLE_ENTAILMENT,
    ENABLE_ZERO_SHOT_CLASSIFIER,
    MIN_ENTAILMENT_SCORE,
    MIN_CLASSIFIER_SCORE,
)


class SnippetRefiner:
    def __init__(self):
        self.entailment = EntailmentChecker() if ENABLE_ENTAILMENT else None
        self.classifier = ZeroShotClassifier() if ENABLE_ZERO_SHOT_CLASSIFIER else None

    def refine_snippets(
        self,
        persona_task: str,
        top_blocks: List[Dict],  # now expects a list of dicts with keys: text, score, document, page_number
    ) -> List[Dict]:
        """
        Refines top blocks using zero-shot classification and entailment (optional).
        Returns a list of dicts with document metadata, scores, and refined content.
        """
        refined_blocks = []

        for block in top_blocks:
            block_text = block["text"]
            sim_score = block.get("score", 1.0)
            entail_score = 1.0
            clf_score = 1.0

            if self.entailment:
                entail_score = self.entailment.check_entailment(block_text, persona_task)
                if entail_score < MIN_ENTAILMENT_SCORE:
                    continue

            if self.classifier:
                clf_score = self.classifier.classify(block_text, persona_task)
                if clf_score < MIN_CLASSIFIER_SCORE:
                    continue

            final_score = (sim_score + entail_score + clf_score) / 3.0

            refined_blocks.append({
                "document": block.get("document", "unknown"),
                "page_number": block.get("page_number", -1),
                "raw": block_text.strip(),
                "refined": block_text.strip(),  # You can later plug a summarizer if needed
                "score": final_score,
            })

        # Sort by final score descending
        return sorted(refined_blocks, key=lambda x: x["score"], reverse=True)
