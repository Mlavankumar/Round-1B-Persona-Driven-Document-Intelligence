# app/pdf_parser.py

import os
import fitz  # PyMuPDF
import fasttext
import cv2
import tempfile
import pytesseract
import numpy as np
from PIL import Image
from typing import List, Dict
from pathlib import Path

from app.config import (
    FASTTEXT_LANG_MODEL_PATH,
    OCR_LANGUAGES,
    MIN_PAGE_TEXT_LENGTH,
    LANG_DETECTION_THRESHOLD
)

# Load FastText language detection model once
lang_model = fasttext.load_model(FASTTEXT_LANG_MODEL_PATH)


def detect_language(text: str) -> str:
    """Detect language using FastText."""
    if not text.strip():
        return "unknown"
    prediction = lang_model.predict(text.replace('\n', ' '), k=1)
    label, confidence = prediction[0][0], prediction[1][0]
    lang_code = label.replace("__label__", "")
    return lang_code if confidence >= LANG_DETECTION_THRESHOLD else "unknown"


def ocr_page_image(pix: fitz.Pixmap) -> str:
    """OCR image-based page using Tesseract."""
    image = Image.frombytes("RGB", [pix.width, pix.height], pix.samples)
    image_np = np.array(image)
    gray = cv2.cvtColor(image_np, cv2.COLOR_RGB2GRAY)
    # Perform OCR with multi-language support
    lang_str = "+".join(OCR_LANGUAGES)
    return pytesseract.image_to_string(gray, lang=lang_str)


def extract_text_from_page(page: fitz.Page) -> str:
    """Extract visible text from a PDF page."""
    return page.get_text("text", sort=True).strip()


def parse_pdf_file(file_path: str) -> Dict:
    """Parse a single PDF file into pages with text, language, and fallback if needed."""
    print(f"[📄] Processing: {file_path}")
    pages_data = []
    doc = fitz.open(file_path)

    for page_num in range(len(doc)):
        page = doc[page_num]
        text = extract_text_from_page(page)

        # Fallback to OCR if text is too short
        if len(text) < MIN_PAGE_TEXT_LENGTH:
            print(f"  [🔎] Page {page_num+1} may be image-based. Running OCR...")
            pix = page.get_pixmap(dpi=300)
            text = ocr_page_image(pix)

        language = detect_language(text)

        pages_data.append({
            "page_num": page_num + 1,
            "text": text,
            "language": language
        })

    return {
        "filename": os.path.basename(file_path),
        "path": file_path,
        "pages": pages_data
    }


def parse_pdf_documents(pdf_dir: str) -> List[Dict]:
    """Parse all PDFs from a given directory."""
    pdf_files = list(Path(pdf_dir).rglob("*.pdf"))
    all_documents = []

    for pdf_path in pdf_files:
        doc_data = parse_pdf_file(str(pdf_path))
        all_documents.append(doc_data)

    return all_documents
