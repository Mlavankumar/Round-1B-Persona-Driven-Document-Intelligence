import numpy as np
import onnxruntime as ort
from app.config import SBERT_MODEL_PATH  # Update this if your model path is different


class IntentEncoder:
    def __init__(self, tokenizer, model_path: str = SBERT_MODEL_PATH):
        """
        Initializes the ONNX-based SBERT encoder for persona-job intent encoding.
        """
        self.tokenizer = tokenizer
        self.session = ort.InferenceSession(model_path, providers=["CPUExecutionProvider"])
        self.input_name = self.session.get_inputs()[0].name
        self.attn_mask_name = self.session.get_inputs()[1].name
        self.output_name = self.session.get_outputs()[0].name

    def _tokenize(self, text: str) -> tuple[np.ndarray, np.ndarray]:
        """
        Tokenizes text using ONNX-compatible tokenizer.
        Assumes ONNXTokenizer.encode(text, "") returns a dict with input_ids and attention_mask.
        """
        encoded = self.tokenizer.encode(text, "")  # Second argument is hypothesis (empty for single sentence)
        return encoded["input_ids"], encoded["attention_mask"]

    def encode_intent(self, persona: str, job_task: str) -> np.ndarray:
        """
        Combines persona + job-task into a single sentence and returns embedding.

        Args:
            persona (str): e.g., "Cybersecurity Analyst in a government agency"
            job_task (str): e.g., "Extract policy and legal compliance sections"

        Returns:
            np.ndarray: 1D float32 embedding vector.
        """
        full_intent = f"{persona.strip()} | Task: {job_task.strip()}"
        input_ids, attention_mask = self._tokenize(full_intent)

        inputs = {
            self.input_name: input_ids.astype(np.int64),
            self.attn_mask_name: attention_mask.astype(np.int64),
        }

        embedding = self.session.run([self.output_name], inputs)[0]
        return embedding.squeeze().astype(np.float32)
