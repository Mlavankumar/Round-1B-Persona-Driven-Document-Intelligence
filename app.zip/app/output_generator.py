# app/output_generator.py

import os
import json
from typing import List, Dict, Any
from uuid import uuid4
from datetime import datetime

class OutputGenerator:
    def __init__(self):
        self.timestamp = datetime.now().isoformat()

    def generate_json_output(
        self,
        persona: str,
        task: str,
        file_metadata: Dict[str, Any],
        top_sections: List[Dict[str, Any]]
    ) -> Dict[str, Any]:
        """
        Generate the final structured JSON output.
        """
        doc_id = str(uuid4())
        output = {
            "doc_id": doc_id,
            "timestamp": self.timestamp,
            "persona": persona,
            "task": task,
            "metadata": file_metadata,
            "num_relevant_sections": len(top_sections),
            "relevant_sections": [],
            "subsection_analysis": []
        }

        for rank, section in enumerate(top_sections, start=1):
            output["relevant_sections"].append({
                "document": section.get("document", ""),
                "page_number": section.get("page_number", -1),
                "section_title": section.get("heading", "")[:100].strip(),
                "importance_rank": rank
            })

            output["subsection_analysis"].append({
                "document": section.get("document", ""),
                "page_number": section.get("page_number", -1),
                "refined_text": section.get("raw", "").strip(),
                "constraints": {
                    "persona": persona,
                    "job_task": task
                }
            })

        return output

    def save_to_json_file(self, output_data: Dict[str, Any], output_path: str) -> None:
        """
        Save the structured output to a JSON file.
        """
        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(output_data, f, ensure_ascii=False, indent=2)
