# app/entailment_checker.py

import onnxruntime as ort
import numpy as np
from typing import Dict
from tokenizer.tokenizer_utils import ONNXTokenizer
from app.config import ENTAILMENT_MODEL_PATH


class EntailmentChecker:
    def __init__(self):
        self.tokenizer = ONNXTokenizer()
        self.session = ort.InferenceSession(ENTAILMENT_MODEL_PATH)

    def check_entailment(self, premise: str, hypothesis: str) -> float:
        inputs = self.tokenizer.encode(premise, hypothesis)
        ort_inputs = {k: np.array([v]) for k, v in inputs.items()}
        logits = self.session.run(None, ort_inputs)[0][0]
        entailment_score = float(logits[2])  # Assume 2 = "entailment"
        return entailment_score
