import re

class SectionExtractor:
    def __init__(self):
        self.section_heading_pattern = re.compile(
            r"^(Section|Chapter|Article|Clause)?\s*(\d+(\.\d+)*)(:|-)?\s*(.+)?$",
            re.IGNORECASE
        )

    def extract_sections(self, blocks):
        sections = []
        current = {
            "heading": "Introduction",
            "content": [],
            "level": 0,
            "raw": "",
            "page_number": -1,
            "document": ""
        }

        for block in blocks:
            text = block["text"] if isinstance(block, dict) else str(block)
            match = self.section_heading_pattern.match(text.strip())

            if match:
                # Save the current section before starting a new one
                if current["content"]:
                    current["raw"] = "\n".join(current["content"])
                    sections.append({
                        "heading": current["heading"],
                        "raw": current["raw"],
                        "document": current["document"],
                        "page_number": current["page_number"]
                    })

                current = {
                    "heading": match.group(0).strip(),
                    "content": [],
                    "level": text.count("."),
                    "raw": "",
                    "page_number": block.get("page_number", -1) if isinstance(block, dict) else -1,
                    "document": block.get("document", "") if isinstance(block, dict) else ""
                }
            else:
                current["content"].append(text)

        # Append the last section
        if current["content"]:
            current["raw"] = "\n".join(current["content"])
            sections.append({
                "heading": current["heading"],
                "raw": current["raw"],
                "document": current["document"],
                "page_number": current["page_number"]
            })

        return sections
