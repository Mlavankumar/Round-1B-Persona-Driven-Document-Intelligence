# src/embedding_model.py

import numpy as np
import onnxruntime as ort
from typing import List
from app.config import SBERT_MODEL_PATH
from transformers import AutoTokenizer

# ✅ Load tokenizer once (for LaBSE or your SBERT model)
tokenizer = AutoTokenizer.from_pretrained("sentence-transformers/LaBSE")

class TransformerEmbedder:
    def __init__(self, model_path: str = SBERT_MODEL_PATH):
        self.session = ort.InferenceSession(model_path, providers=["CPUExecutionProvider"])
        self.input_name = self.session.get_inputs()[0].name
        self.attn_name = self.session.get_inputs()[1].name

    def encode(self, texts: List[str], batch_size: int = 32) -> np.ndarray:
        # ✅ Validate inputs
        texts = [text.strip() for text in texts if isinstance(text, str) and text.strip()]
        if not texts:
            raise ValueError("No valid input texts provided for encoding.")

        all_embeddings = []

        for i in range(0, len(texts), batch_size):
            batch = texts[i:i + batch_size]
            inputs = tokenizer(batch, padding=True, truncation=True, return_tensors="np")

            ort_inputs = {
                self.input_name: inputs["input_ids"],
                self.attn_name: inputs["attention_mask"]
            }

            try:
                outputs = self.session.run(None, ort_inputs)
                embeddings = outputs[0]  # shape: (batch_size, embedding_dim)
                all_embeddings.append(embeddings)
            except Exception as e:
                print(f"[❌] ONNX inference failed on batch {i}: {e}")
                continue

        if not all_embeddings:
            raise RuntimeError("All batches failed during ONNX inference.")

        return np.vstack(all_embeddings)  # shape: (total_samples, embedding_dim)
