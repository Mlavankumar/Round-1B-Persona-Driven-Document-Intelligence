# src/tokenizers.py

import numpy as np
from transformers import AutoTokenizer


class ONNXTokenizer:
    def __init__(self, model_name: str = "bert-base-uncased", max_length: int = 128):
        """
        Loads the tokenizer from Hugging Face model hub (should match the model used to export the ONNX model).
        """
        self.tokenizer = AutoTokenizer.from_pretrained(model_name)
        self.max_length = max_length

    def encode(self, premise: str, hypothesis: str) -> dict:
        """
        Encodes a sentence pair (e.g., intent + document snippet) into input tensors.

        Returns:
            dict with input_ids, attention_mask, token_type_ids (all numpy arrays, dtype=int64)
        """
        tokens = self.tokenizer.encode_plus(
            premise,
            hypothesis,
            max_length=self.max_length,
            truncation=True,
            padding="max_length",
            return_tensors="np"
        )
        return {
            "input_ids": tokens["input_ids"].astype(np.int64),
            "attention_mask": tokens["attention_mask"].astype(np.int64),
            "token_type_ids": tokens["token_type_ids"].astype(np.int64),
        }

    def encode_batch(self, texts: list[str]) -> dict:
        """
        Encodes a batch of single sentences (not pairs) for bulk inference.
        Returns:
            dict of input_ids and attention_mask (numpy arrays).
        """
        tokens = self.tokenizer.batch_encode_plus(
            texts,
            max_length=self.max_length,
            truncation=True,
            padding="max_length",
            return_tensors="np"
        )
        return {
            "input_ids": tokens["input_ids"].astype(np.int64),
            "attention_mask": tokens["attention_mask"].astype(np.int64),
        }
